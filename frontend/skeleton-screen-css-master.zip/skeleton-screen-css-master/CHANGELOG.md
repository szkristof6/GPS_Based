# 1.1.0

1. **Remove** line margin bottom - use mb, mbs or custom style rule instead;
2. **Remove** ie11 from browserlist;
3. **Reduce** bundle size;
4. **Add** some flexbox helper classes;
5. **Improve** examples and docs;